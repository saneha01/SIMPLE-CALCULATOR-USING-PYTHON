def add(a,b):
    return a + b

def subtract(a,b):
    return a - b

def multiply(a,b):
    return a*b

def divide(a,b):
    if(b==0):
        return ZeroDivisionError("cannot divide by zero")
    else:
        return a/b
    
def calculate(a,operator,b):
    if operator == "+":
        return add(a,b)
    
    elif operator == "-":
        return subtract(a,b)
    
    elif operator == "*":
        return multiply(a,b)
    
    elif operator == "/":
        return divide(a,b)
    
    else:
        return ValueError("invalid operator")

def calculator():
    print("-- SIMPLE CALCULATOR --")
    while True:
        print("\n MENU \n")
        print("press 1 for calculation /n")
        print("press 2 for exit ")
        choice = int(input("chose the option 1 or 2 "))
        if choice == 1:
            a = int(input("enter the number a : "))
            operator = input("enter the operator: ")
            b = int(input("enter the number b :"))

            output = calculate(a,operator,b)
            print(output)
        elif choice == 2:
            print("exiting the calculator ")
            
        else:
            print("invalid choice -")
calculator()

    

